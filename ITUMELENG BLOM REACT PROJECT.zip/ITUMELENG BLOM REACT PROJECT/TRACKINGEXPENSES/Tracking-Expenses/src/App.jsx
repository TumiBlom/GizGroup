import React from 'react'
import React, { useState } from 'react';

function App() {
  const [expenses, setExpenses] = useState([]);
  const [newExpense, setNewExpense] = useState('');

  const addExpense = () => {
    if (newExpense.trim() !== '') {
      setExpenses([...expenses, newExpense]);
      setNewExpense('');
    }
  };

  return (
    <div>
      <h1>Expense Tracker</h1>
      <ul>
        {expenses.map((expense, index) => (
          <li key={index}>{expense}</li>
        ))}
      </ul>
      <div>
        <input
          type="text"
          value={newExpense}
          onChange={(e) => setNewExpense(e.target.value)}
        />
        <button onClick={addExpense}>Add Expense</button>
      </div>
    </div>
  );
}

export default App;
